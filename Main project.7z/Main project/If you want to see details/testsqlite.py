import sqlite3

db = sqlite3.connect('../Chatbot/HAI.sqlite')
cursor = db.cursor()
cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='My_Favourite_movie_list'")
result = cursor.fetchone()
if result:
    print("Table 'My_Favourite_movie_list' exists.")
else:
    print("Table 'My_Favourite_movie_list' does not exist.")
cursor.close()
db.close()
