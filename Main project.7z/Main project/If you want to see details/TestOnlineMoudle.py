from transformers import AutoModelForSequenceClassification, AutoTokenizer
import torch
model_path = "DSWF/intent-classification-model"
model = AutoModelForSequenceClassification.from_pretrained(model_path)
tokenizer = AutoTokenizer.from_pretrained(model_path)


def test_model_on_input(user_input):

    inputs = tokenizer(user_input, return_tensors="pt", truncation=True, padding=True, max_length=512)
    with torch.no_grad():
        outputs = model(**inputs)
        logits = outputs.logits

    predicted_class = torch.argmax(logits, dim=-1).item()
    id2label = model.config.id2label
    predicted_label = id2label[predicted_class]
    return predicted_label


while True:
    user_input = input("Please enter a sentence to classify (or type 'exit' to quit): ")
    if user_input.lower() == "exit":
        print("Exiting the program.")
        break
    predicted_label = test_model_on_input(user_input)
    print(f"Predicted Label: {predicted_label}")
