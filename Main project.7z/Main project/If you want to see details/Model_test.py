from transformers import AutoModelForSequenceClassification, AutoTokenizer
import torch

model_path = "DSWF/intent-classification-model"
model = AutoModelForSequenceClassification.from_pretrained(model_path)
tokenizer = AutoTokenizer.from_pretrained(model_path)

def model_on_input(user_input):
    inputs = tokenizer(user_input, return_tensors="pt", truncation=True, padding=True, max_length=512)

    with torch.no_grad():
        outputs = model(**inputs)
        logits = outputs.logits

    predicted_class = torch.argmax(logits, dim=-1).item()
    id2label = model.config.id2label  # id
    predicted_label = id2label[predicted_class]
    return predicted_label


while (True):
    user_input = input("Please enter a sentence to classify: ")
    predicted_label = model_on_input(user_input)
    print(f"Predicted Label: {predicted_label}")
