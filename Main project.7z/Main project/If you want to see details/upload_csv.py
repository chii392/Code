from datasets import Dataset
from huggingface_hub import login

login(token="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")
#dataset1
conversation_data_path = "../conversations1.csv"
conversation_repo_name = "conversation-dataset"

#dataset2
movie_data_path = "../9000plus.csv"
movie_repo_name = "movie-dataset"

print("Uploading conversations1.csv...")
conversation_dataset = Dataset.from_csv(conversation_data_path)
conversation_dataset.push_to_hub(repo_id=f"DSWF/{conversation_repo_name}")
print(f"Conversations dataset uploaded to: https://huggingface.co/datasets/DSWF/{conversation_repo_name}")

print("Uploading 9000plus.csv...")
movie_dataset = Dataset.from_csv(movie_data_path)
movie_dataset.push_to_hub(repo_id=f"DSWF/{movie_repo_name}")
print(f"Movie dataset uploaded to: https://huggingface.co/datasets/DSWF/{movie_repo_name}")
