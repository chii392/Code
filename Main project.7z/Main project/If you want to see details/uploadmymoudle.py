from transformers import AutoModelForSequenceClassification, AutoTokenizer
hf_username = "DSWF"
repo_name = "intent-classification-model"
model_path = r"../Model_Class"

model = AutoModelForSequenceClassification.from_pretrained(model_path)
tokenizer = AutoTokenizer.from_pretrained(model_path)

model.push_to_hub(f"{hf_username}/{repo_name}")
tokenizer.push_to_hub(f"{hf_username}/{repo_name}")

print(f"Successfully upload to Hugging Face Hub: https://huggingface.co/{hf_username}/{repo_name}")


#a little bit big  400mb