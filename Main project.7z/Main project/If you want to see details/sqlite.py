import sqlite3

db = sqlite3.connect("../Chatbot/HAI.sqlite")
cursor = db.cursor()

cursor.close()
db.close()
