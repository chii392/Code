#Use mysql firstly but has some problem with school net
import mysql.connector
try:
    db = mysql.connector.connect(
        host="185.31.40.40",
        user="junyi",
        password="bwss13579",
        database="junyi_hai",
        port=3306
    )
    cursor = db.cursor()
    cursor.execute("SELECT 1")
    result = cursor.fetchone()

    if result:
        print("Connection successful, ping test passed.")
    else:
        print("Connection failed.")
except mysql.connector.Error as err:
    print(f"Error: {err}")
finally:
    if db.is_connected():
        cursor.close()
        db.close()
