import pandas as pd
from sklearn.model_selection import train_test_split
from datasets import Dataset
from transformers import AutoTokenizer, AutoModelForSequenceClassification, Trainer, TrainingArguments, EarlyStoppingCallback
from sklearn.metrics import accuracy_score, precision_recall_fscore_support

csv_path = r"../Final_altered.csv"
output_dir = r"E:\Human-AIDataset\Updated\Model_Class"

#clean
df = pd.read_csv(csv_path)

# Text
df["Text"] = df["Text"].astype(str)

# factorize labels
df["labels"] = pd.factorize(df["Intent"])[0]

# train_test_split 80% 20%
train_df, test_df = train_test_split(df, test_size=0.2, stratify=df["labels"], random_state=42)

# Dataset
train_dataset = Dataset.from_pandas(train_df)
test_dataset = Dataset.from_pandas(test_df)

# tokenizer
model_name = "bert-base-uncased"
tokenizer = AutoTokenizer.from_pretrained(model_name)

# Tokenize
def tokenize_function(examples):
    return tokenizer(examples["Text"], padding="max_length", truncation=True)

tokenized_train_datasets = train_dataset.map(tokenize_function, batched=True)
tokenized_test_datasets = test_dataset.map(tokenize_function, batched=True)


tokenized_train_datasets = tokenized_train_datasets.with_format("torch")
tokenized_test_datasets = tokenized_test_datasets.with_format("torch")


num_labels = len(df["Intent"].unique())
id2label = {i: label for i, label in enumerate(df["Intent"].unique())}
label2id = {label: i for i, label in enumerate(df["Intent"].unique())}


model = AutoModelForSequenceClassification.from_pretrained(
    model_name,
    num_labels=num_labels,
    id2label=id2label,
    label2id=label2id
)


def compute_metrics(pred):
    labels = pred.label_ids
    preds = pred.predictions.argmax(-1)
    precision, recall, f1, _ = precision_recall_fscore_support(labels, preds, average="weighted")
    acc = accuracy_score(labels, preds)
    return {"accuracy": acc, "f1": f1, "precision": precision, "recall": recall}

training_args = TrainingArguments(
    output_dir=output_dir,
    num_train_epochs=2,
    per_device_train_batch_size=16,
    per_device_eval_batch_size=16,
    evaluation_strategy="epoch",
    save_strategy="epoch",
    logging_dir=f"{output_dir}/logs",
    logging_steps=50,
    save_total_limit=3,
    learning_rate=3e-5,
    weight_decay=0.01,
    warmup_steps=50,
    gradient_accumulation_steps=2,
    logging_first_step=True,
    report_to="tensorboard",
    metric_for_best_model="accuracy",
    load_best_model_at_end=True,
)

# EarlyStoppingCallback
early_stopping = EarlyStoppingCallback(early_stopping_patience=1)


trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=tokenized_train_datasets,
    eval_dataset=tokenized_test_datasets,
    tokenizer=tokenizer,
    compute_metrics=compute_metrics,
    callbacks=[early_stopping],
)


trainer.train()


model.save_pretrained(output_dir)
tokenizer.save_pretrained(output_dir)


print(f"Training has finished and saved {output_dir}")


print("\n(id2label):", id2label)
print("\n(label2id):", label2id)



results = trainer.evaluate(tokenized_test_datasets)


print("Finish and result:", results)
