import sqlite3
import requests
import pandas as pd
import re
import spacy
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import random
import webbrowser
from datetime import date
from transformers import pipeline
from datetime import datetime
import warnings  #Just for better visualization and faster
import time

warnings.simplefilter('ignore', FutureWarning)
nltk.download('punkt')  #NLTk
nltk.download('stopwords')
nlp = spacy.load("en_core_web_sm")  #for movie title

# TF-IDF
vectorizer = TfidfVectorizer(stop_words='english')
db = sqlite3.connect("HAI.sqlite")
cursor = db.cursor()

#My model too big(400mb) so upload to internet ->here is my model
#https://huggingface.co/DSWF/intent-classification-model/tree/main
model_path = "DSWF/intent-classification-model"
model = AutoModelForSequenceClassification.from_pretrained(model_path)
tokenizer = AutoTokenizer.from_pretrained(model_path)

# Movie dataset
movie_df = pd.read_csv("../9000plus.csv", encoding="utf-8")
movie_df = movie_df.dropna(subset=['Title'])
movie_titles = movie_df['Title'].tolist()

# Conversation dataset
conversation_df = pd.read_csv("../conversations1.csv", encoding="utf-8")
conversation_df = conversation_df.dropna(subset=['Text', 'Answer'])

'''
# mysql
db = mysql.connector.connect(
    host="185.31.40.40",              #school internet has some limitations cant ping through
    user="junyi",
    password="bwss13579",
    database="junyi_hai",
    port=3306
)
cursor = db.cursor()
'''
#"Only two advanced features require real-time data queries, which will use the following APIs,
# and they are only applied to Tag 7 and Tag 19. The rest are implemented locally through the database and dataset (CSV)."

# Not using as Main function just for Query real-time information---id2label 19
BING_API_KEY = "96b3f7e86ded49c2956ec26cccc141b5"
BING_SEARCH_URL = "https://api.bing.microsoft.com/v7.0/search"
#not the main function, only used when the user needs to query the cinema.---id2label7
AZURE_MAPS_KEY = "ErrxmXiKIfXNgguy3tiYhMn1RKEa78UbjPo3dfXs7qgzr2MkY9CsJQQJ99AKAC5RqLJwd00xAAAgAZMP24OH"
SEARCH_API_URL = "https://atlas.microsoft.com/search/poi/json"
GEOCODE_API_URL = "https://atlas.microsoft.com/search/address/json"

#Inetents
id2label = {
    0: 'create_favorite_movie_list',
    1: 'add_movie_to_list',
    2: 'remove_movie_from_list',
    3: 'query_movie_list',
    4: 'modify_movie_list',
    5: 'single_movie_recommendation',
    6: 'multiple_movie_recommendations',
    7: 'recommend_ticket_purchase',
    8: 'confirm',
    9: 'deny',
    10: 'recommend_similar_movies',
    11: 'recommend_streaming_sites',
    12: 'movie_release_date',
    13: 'movie_overview',
    14: 'movie_popularity',
    15: 'movie_vote_average',
    16: 'movie_genre',
    17: 'movie_poster_url',
    18: 'movie_original_language',
    19: 'daily_conversation2',
    20: 'daily_conversation1'
}

def adapt_date(date_obj):
    return date_obj.isoformat()

def adapt_datetime(datetime_obj):
    return datetime_obj.isoformat()

sqlite3.register_adapter(date, adapt_date)
sqlite3.register_adapter(datetime, adapt_datetime)

# check list empty
def check_favorite_movie_list():
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='My_Favourite_movie_list'")
    result = cursor.fetchone()
    return result is not None

# create movie list
def create_favorite_movie_list():
    if check_favorite_movie_list():
        print("Bot: Your movie list already exists,Now you can add movies into list.")
        return
    # create in sqlite
    create_table_query = """
    CREATE TABLE IF NOT EXISTS My_Favourite_movie_list (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        priority INTEGER NOT NULL,
        add_date TEXT NOT NULL,
        genre TEXT,
        popularity REAL,
        planning_time TEXT
    )
    """
    try:
        cursor.execute(create_table_query)
        db.commit()
        print("Bot: Your favorite movie list has been created! You can now add movies into it.")
    except Exception as e:
        db.rollback()
        print(f"Bot: Error occurred while creating the table: {e}")

def modify_movie_list():
    print("Bot: Which movie do you want to modify?")
    # Insert title
    user_input = input(f"{user_name}: ")
    # Use spaCy and nltk
    doc = nlp(user_input)
    movie_name = None
    for ent in doc.ents:
        if ent.label_ == 'WORK_OF_ART':
            movie_name = ent.text
            break
    if not movie_name:
        movie_name_match = re.search(r"\b([A-Za-z0-9]+(?:[\s-][A-Za-z0-9]+)*)\b", user_input)
        if movie_name_match:
            movie_name = movie_name_match.group(1)
    if not movie_name:
        print("Bot: Sorry, I couldn't detect a movie title. Can you provide more details?")
        return
    # Best match
    cleaned_user_input = clean_text(movie_name)
    movie_titles_cleaned = [clean_text(title) for title in movie_titles]
    all_titles = movie_titles_cleaned + [cleaned_user_input]
    try:
        tfidf_vectorizer = TfidfVectorizer(stop_words='english')
        tfidf_matrix = tfidf_vectorizer.fit_transform(all_titles)
    except Exception as e:
        print(f"Bot: Error processing movie data: {e}")
        print("Bot: Please check if your movie dataset is available and not empty.")
        return

    cosine_similarities = cosine_similarity(tfidf_matrix[-1], tfidf_matrix[:-1])
    best_match_idx = cosine_similarities.argmax()
    best_match = movie_titles[best_match_idx]

    # Check if the movie is in the database
    if best_match is None or best_match not in movie_titles:
        print("Bot: Sorry, I couldn't find the movie in the dataset. Please make sure the movie is in your list.")
        return
    # Matched movie details
    matched_movie = movie_df[movie_df['Title'] == best_match].iloc[0]
    # Which movie to alter
    print(f"Bot: You selected '{best_match}'. What movie would you like to replace it with?")
    new_movie_name = input(f"{user_name}: ")
    # Change
    cleaned_new_movie_input = clean_text(new_movie_name)
    all_titles = movie_titles_cleaned + [cleaned_new_movie_input]
    try:
        tfidf_matrix = tfidf_vectorizer.fit_transform(all_titles)
    except Exception as e:
        print(f"Bot: Error processing new movie data: {e}")
        return

    cosine_similarities = cosine_similarity(tfidf_matrix[-1], tfidf_matrix[:-1])
    best_match_new_movie_idx = cosine_similarities.argmax()
    best_match_new_movie = movie_titles[best_match_new_movie_idx]

    if best_match_new_movie is None or best_match_new_movie not in movie_titles:
        print("Bot: Sorry, I couldn't find the new movie in the dataset. Please make sure the movie is in your list.")
        return
    # Matched new movie details
    matched_new_movie = movie_df[movie_df['Title'] == best_match_new_movie].iloc[0]
    today_date = date.today()
    # Get original planning_time from the database
    cursor.execute("SELECT planning_time FROM My_Favourite_movie_list WHERE title = ?", (best_match,))
    planning_time = cursor.fetchone()
    if planning_time:
        planning_time = planning_time[0]
    else:
        planning_time = "Not Set"
    # Update the movie data in the database
    update_movie_query = """
    UPDATE My_Favourite_movie_list
    SET title = ?, genre = ?, popularity = ?, add_date = ?
    WHERE title = ?
    """

    matched_new_movie['Popularity'] = float(matched_new_movie['Popularity'])
    try:
        cursor.execute(update_movie_query, (matched_new_movie['Title'], matched_new_movie['Genre'],
                                            matched_new_movie['Popularity'], today_date, best_match))

        # Update the planning_time
        update_planning_time_query = """
        UPDATE My_Favourite_movie_list
        SET planning_time = ?
        WHERE title = ?
        """
        cursor.execute(update_planning_time_query, (planning_time, matched_new_movie['Title']))
        db.commit()
        print(
            f"Bot: Successfully updated '{best_match}' to '{matched_new_movie['Title']}' in your favorite movie list.")
    except Exception as e:
        db.rollback()
        print(f"Bot: Failed to update the movie. Error: {e}")

def add_movie_to_list(user_input):
    doc = nlp(user_input)
    movie_name = None
    for ent in doc.ents:
        if ent.label_ == 'WORK_OF_ART':
            movie_name = ent.text
            break

    if not movie_name:
        movie_name_match = re.search(r"\b([A-Za-z0-9]+(?:[\s-][A-Za-z0-9]+)*)\b", user_input)
        if movie_name_match:
            movie_name = movie_name_match.group(1)

    if not movie_name:
        print(
            "Bot: Sorry, I couldn't detect a movie title. Can you provide more details?\nMaybe the dataset is not big enough")
        return

    cleaned_user_input = clean_text(movie_name)

    movie_titles_cleaned = [clean_text(title) for title in movie_titles]
    all_titles = movie_titles_cleaned + [cleaned_user_input]

    try:
        tfidf_matrix = vectorizer.fit_transform(all_titles)
    except Exception as e:
        print(f"Bot: Error processing movie data: {e}")
        return

    cosine_similarities = cosine_similarity(tfidf_matrix[-1], tfidf_matrix[:-1])
    best_match_idx = cosine_similarities.argmax()
    best_match = movie_titles[best_match_idx]

    if cosine_similarities[0][best_match_idx] < 0.2:
        print("Bot: Sorry, I couldn't find a movie that matches your request.")
        return

    matched_movie = movie_df[movie_df['Title'] == best_match].iloc[0]
    movie_title = matched_movie['Title']
    movie_genre = matched_movie.get('Genre', 'Unknown')
    movie_popularity = matched_movie.get('Popularity', 0.0)

    print(
        f"Bot: I found the movie '{movie_title}' in my dataset. Would you like to add it to your favorite movie list?")

    while True:
        user_response = input(f"{user_name}: ")
        intent = classify_intent(user_response)
        if intent == 'confirm':
            while True:
                print("Bot: Please set a priority for this movie (1-10):")
                priority_input = input(f"{user_name}: ")
                if priority_input.isdigit() and 1 <= int(priority_input) <= 10:
                    priority = int(priority_input)
                    break
                else:
                    print("Bot: Invalid input. Please enter an integer between 1 and 10.")
            movie_popularity = float(movie_popularity)
            while True:
                print("Bot: Please enter your planning time in 'YYYY-MM-DD-HH.MM'(e.g 2024-11-27-15.00)")
                time_input = input(f"{user_name}: ").strip()
                if time_input == "":
                    planning_time = None
                    break
                try:
                    if re.match(r'^\d{4}-\d{2}-\d{2}-\d{2}$', time_input):
                        time_input += '.00'
                    planning_time = datetime.strptime(time_input, "%Y-%m-%d-%H.%M")

                    # Explicitly convert planning_time to correct format
                    planning_time_str = planning_time.strftime('%Y-%m-%d %H:%M:%S')

                    check_query = """
                    SELECT * FROM My_Favourite_movie_list 
                    WHERE strftime('%Y-%m-%d-%H', planning_time) = strftime('%Y-%m-%d-%H', ?)
                    """
                    cursor.execute(check_query, (planning_time_str,))
                    if cursor.fetchone():
                        print("Bot: A plan already exists for this date and hour. Please choose another time.")
                    else:
                        break
                except ValueError:
                    print("Bot: Invalid format. Please try again.")
            try:
                insert_query = """
                INSERT INTO My_Favourite_movie_list (title, priority, add_date, genre, popularity, planning_time)
                VALUES (?, ?, ?, ?, ?, ?)
                """
                today_date = date.today()
                today_date_str = today_date.strftime('%Y-%m-%d')  # Convert today_date to string
                cursor.execute(insert_query,
                               (movie_title, priority, today_date_str, movie_genre, movie_popularity, planning_time_str))
                db.commit()
                print(f"Bot: Movie '{movie_title}' has been successfully added with planning time {planning_time_str}!")
            except Exception as e:
                db.rollback()
                print(f"Bot: Failed to add the movie. Error: {e}")
            return
        elif intent == 'deny':
            print("Bot: Is it because the movie title is incorrect?")
            while True:
                user_response = input(f"{user_name}: ")
                title_error_intent = classify_intent(user_response)
                if title_error_intent == 'confirm':
                    print("Bot: Okay then please provide a more detailed movie title.")
                    new_user_input = input(f"{user_name}: ")
                    return add_movie_to_list(new_user_input)
                elif title_error_intent == 'deny':
                    print("Bot: Okay, I will not add this movie to your list.")
                    return
                else:
                    print("Bot: Sorry, I didn't quite understand your intention. Could you clarify?")


def delete_movie_from_list(user_input):
    doc = nlp(user_input)
    movie_name = None
    for ent in doc.ents:
        if ent.label_ == 'WORK_OF_ART':
            movie_name = ent.text
            break

    if not movie_name:
        movie_name_match = re.search(r"\b([A-Za-z0-9]+(?:[\s-][A-Za-z0-9]+)*)\b", user_input)
        if movie_name_match:
            movie_name = movie_name_match.group(1)

    if not movie_name:
        print("Bot: Sorry, I couldn't detect a movie title. Can you provide more details?")
        return

    cleaned_user_input = clean_text(movie_name)
    movie_titles_cleaned = [clean_text(title) for title in movie_titles]
    all_titles = movie_titles_cleaned + [cleaned_user_input]
    tfidf_matrix = vectorizer.fit_transform(all_titles)
    cosine_similarities = cosine_similarity(tfidf_matrix[-1], tfidf_matrix[:-1])
    best_match_idx = cosine_similarities.argmax()
    best_match = movie_titles[best_match_idx]
    if cosine_similarities[0][best_match_idx] < 0.2:
        print("Bot: Sorry, I couldn't find a movie that matches your request.")
        return
    matched_movie = movie_df[movie_df['Title'] == best_match].iloc[0]
    movie_title = matched_movie['Title']
    print(f"Bot: I found the movie '{movie_title}' in my dataset. Would you like to delete it from your favorite movie list?")
    while True:
        user_response = input(f"{user_name}: ")
        intent = classify_intent(user_response)
        if intent == 'confirm':
            try:
                delete_query = "DELETE FROM My_Favourite_movie_list WHERE title = ?"
                cursor.execute(delete_query, (movie_title,))
                db.commit()
                print(f"Bot: Movie '{movie_title}' has been successfully deleted from your list!")
            except Exception as e:
                db.rollback()
                print(f"Bot: Failed to delete the movie. Error: {e}")
            return
        elif intent == 'deny':
            print("Bot: Okay, I won't delete it.")
            return
        else:
            print("Bot: Sorry, I didn't quite understand that. Please respond with 'yes' or 'no'.")


def query_movie_list():
    try:
        # sequence
        query = "SELECT * FROM My_Favourite_movie_list ORDER BY priority DESC"
        cursor.execute(query)
        results = cursor.fetchall()
        if not results:
            print("Bot: Your movie list is empty.")
            return
        print("Bot: Here is your movie list:")
        # Header for the table, including planning_time column
        print("{:<5} {:<30} {:<10} {:<15} {:<10} {:<20}".format(
            "ID", "Title", "Priority", "Add Date", "Genre", "Planning Time"))
        for row in results:
            if isinstance(row[3], str):  # SQLite stores dates as strings
                add_date = row[3]
            else:
                add_date = str(row[3])
            if isinstance(row[6], str):  # Assuming stored as 'YYYY-MM-DD HH:MM'
                planning_time = row[6]
            else:
                planning_time = "Not Set"
            print("{:<5} {:<30} {:<10} {:<15} {:<10} {:<20}".format(
                row[0], row[1], row[2], add_date, row[4], planning_time))
    except Exception as e:
        print(f"Bot: Failed to query your movie list. Error: {e}")

def recommend_similar_movies(user_input):
    doc = nlp(user_input)
    movie_name = None
    for ent in doc.ents:
        if ent.label_ == 'WORK_OF_ART':
            movie_name = ent.text
            break
    if not movie_name:
        movie_name_match = re.search(r"\b([A-Za-z0-9]+(?:[\s-][A-Za-z0-9]+)*)\b", user_input)
        if movie_name_match:
            movie_name = movie_name_match.group(1)
    if not movie_name:
        print("Bot: Sorry, I couldn't detect a movie title. Can you provide more details?")
        return
    cleaned_user_input = clean_text(movie_name)
    movie_titles_cleaned = [clean_text(title) for title in movie_titles]
    all_titles = movie_titles_cleaned + [cleaned_user_input]
    try:
        tfidf_vectorizer = TfidfVectorizer(stop_words='english')
        tfidf_matrix = tfidf_vectorizer.fit_transform(all_titles)
    except Exception as e:
        print(f"Bot: Error processing movie data: {e}")
        print("Bot: Please check if your movie dataset is available and not empty.")
        return
    cosine_similarities = cosine_similarity(tfidf_matrix[-1], tfidf_matrix[:-1])
    best_match_idx = cosine_similarities.argmax()
    best_match = movie_titles[best_match_idx]
    if best_match is None or best_match not in movie_df['Title'].values:
        print("Bot: Sorry, I couldn't find the movie in the dataset. Please make sure the movie is in your list.")
        return
    matched_movie = movie_df[movie_df['Title'] == best_match].iloc[0]
    try:
        movie_genre = matched_movie['Genre']
        movie_popularity = matched_movie['Popularity']
    except KeyError as e:
        print(f"Bot: Missing required movie data (e.g., Genre or Popularity). Please ensure the movie data is complete.")
        return
    if movie_df.empty:
        print("Bot: Your movie list is empty. Please add movies to your list first.")
        return
    while True:
        try:
            print("Bot: How many similar movies would you like me to recommend? ")
            num_recommendations = int(input(f"{user_name}:"))
            if num_recommendations <= 0:
                print("Bot: Please enter a positive number.")
            else:
                break
        except ValueError:
            print("Bot: Please enter a valid integer.")
    similar_movies = movie_df[movie_df['Genre'] == movie_genre]
    if similar_movies.empty:
        print(f"Bot: No similar movies found for '{best_match}' based on the genre. You may want to try adding more movies with a similar genre.")
        return
    similar_movies = similar_movies.copy()
    similar_movies['popularity_diff'] = (similar_movies['Popularity'] - movie_popularity).abs()
    similar_movies = similar_movies.sort_values(by=['popularity_diff'], ascending=True)
    recommended_movies = similar_movies.head(num_recommendations)['Title'].tolist()
    print(f"Bot: Here are {num_recommendations} similar movies to '{best_match}':")
    for idx, title in enumerate(recommended_movies, 1):
        print(f"{idx}. {title}")
    print("Bot: This recommendation is based on your habits.")

movie_data_path = "../9000plus.csv"
df = pd.read_csv(movie_data_path)
df['Popularity'] = pd.to_numeric(df['Popularity'], errors='coerce')
df['Vote_Average'] = pd.to_numeric(df['Vote_Average'], errors='coerce')
df['Vote_Count'] = pd.to_numeric(df['Vote_Count'], errors='coerce')
classifier = pipeline("zero-shot-classification", model="facebook/bart-large-mnli", force_download=True)

# Intents detect
def parse_user_input(user_input):
    doc = nlp(user_input.lower())
    genres = ['action', 'comedy', 'drama', 'thriller', 'horror', 'romance', 'animation', 'family', 'adventure', 'crime', 'science fiction', 'fantasy', 'mystery']
    genre_keywords = [genre for genre in genres if genre in user_input.lower()]
    high_rate = "high rate" in user_input.lower() or "high rated" in user_input.lower()
    return genre_keywords, high_rate

# filter
def filter_movies(user_input):
    genre_keywords, high_rate = parse_user_input(user_input)
    avg_popularity = df['Popularity'].mean()
    avg_vote_average = df['Vote_Average'].mean()
    avg_vote_count = df['Vote_Count'].mean()
    filtered_df = df[
        (df['Popularity'] >= avg_popularity) &
        (df['Vote_Average'] >= avg_vote_average) &
        (df['Vote_Count'] >= avg_vote_count)
    ]
    if high_rate:
        filtered_df = filtered_df[filtered_df['Vote_Average'] > avg_vote_average]
    if genre_keywords:
        filtered_df = filtered_df[filtered_df['Genre'].apply(
            lambda x: all(genre in x.lower() for genre in genre_keywords)
        )]
    return filtered_df

# single recommend
def recommend_single_movie(filtered_df):
    if len(filtered_df) == 0:
        return "No movies found matching your preferences."
    movie = filtered_df.sample(n=1)
    movie_info = movie.iloc[0]
    return (f"Based on your preferences, I recommend the movie '{movie_info['Title']}'.\n"
            f"Release Date: {movie_info['Release_Date']}\n"
            f"Popularity: {movie_info['Popularity']}\n"
            f"Vote Count: {movie_info['Vote_Count']}\n"
            f"Vote Average: {movie_info['Vote_Average']}\n"
            f"Original Language: {movie_info['Original_Language']}\n"
            f"Genre: {movie_info['Genre']}")

# +2 recommend
def recommend_multiple_movies(filtered_df, num_recommendations=5):
    if len(filtered_df) == 0:
        return "No movies found matching your preferences."
    movies = filtered_df.sample(n=num_recommendations)
    recommendations = "Here are some movie recommendations:\n"
    for _, movie in movies.iterrows():
        recommendations += (f"'{movie['Title']}'\n"
                            f"   Release Date: {movie['Release_Date']}\n"
                            f"   Popularity: {movie['Popularity']}\n"
                            f"   Vote Count: {movie['Vote_Count']}\n"
                            f"   Vote Average: {movie['Vote_Average']}\n"
                            f"   Original Language: {movie['Original_Language']}\n"
                            f"   Genre: {movie['Genre']}\n\n")
    return recommendations

def search_bing_with_snippets(query):      #Maybe can also use Crawler to get keyword?

    headers = {"Ocp-Apim-Subscription-Key": BING_API_KEY}
    params = {"q": query, "count": 3}
    response = requests.get(BING_SEARCH_URL, headers=headers, params=params)
    if response.status_code == 200:
        data = response.json()
        snippets = []
        links = []
        for web_page in data.get("webPages", {}).get("value", []):
            snippet = web_page.get("snippet", "No description available.")
            link = web_page.get("url", "")
            snippets.append(snippet)
            links.append(link)
        response_text = "Here's what I found:\n"
        for idx, snippet in enumerate(snippets):
            response_text += f"{idx + 1}. {snippet}\n"
        response_text += "\nLinks to explore further:\n"
        response_text += "\n".join([f"{idx + 1}. {link}" for idx, link in enumerate(links)])
        return response_text
    else:
        return f"Error: Unable to fetch results (status code: {response.status_code})."

def recommend_ticket_purchase():
    print("Bot: Please enter your postal code (e.g., NG7 2GJ):")
    user_postal_code = input(f"{user_name}: ").strip().upper()
    # postcode structure (new thing for me
    if not re.match(r"^[A-Z0-9\s]+$", user_postal_code):
        print("Bot: Invalid postal code format. Please enter a valid postal code.")
        return
    geocode_params = {
        "api-version": "1.0",
        "subscription-key": AZURE_MAPS_KEY,
        "query": user_postal_code,
    }
    response = requests.get(GEOCODE_API_URL, params=geocode_params)
    if response.status_code != 200 or not response.json().get('results'):
        print("Bot: Unable to find the location for the provided postal code. Please try again.")
        return
    position = response.json()['results'][0]['position']
    latitude, longitude = position['lat'], position['lon']
    search_params = {
        "api-version": "1.0",
        "subscription-key": AZURE_MAPS_KEY,
        "query": "cinema",
        "limit": 4,  # Can be changed
        "lat": latitude,
        "lon": longitude,
    }
    search_response = requests.get(SEARCH_API_URL, params=search_params)
    if search_response.status_code != 200 or not search_response.json().get('results'):
        print("Bot: Sorry, I couldn't find any cinemas near your location.")
        return
    cinemas = search_response.json()['results']
    print(f"Bot: Here are cinemas near {user_postal_code}:")
    for idx, cinema in enumerate(cinemas, 1):
        name = cinema['poi'].get('name', 'Cinema name not available')
        address = cinema['address'].get('freeformAddress', 'Address not available')
        opening_hours = cinema['poi'].get('openingHours', {}).get('text', 'Opening hours not available')
        print(f"{idx}. {name}")
        print(f"   Address: {address}")
        print(f"   Hours: {opening_hours}\n")
    print("Bot: Do you want to ask somewhere else? (Yes/No)")
    user_response = input(f"{user_name}: ").strip().lower()
    try:
        inputs = tokenizer(user_response, return_tensors="pt", truncation=True, padding=True, max_length=512)
    except Exception as e:
        print(f"Error during tokenization: {e}")

    # ues model to eval
    model.eval()
    with torch.no_grad():
        outputs = model(**inputs)
    logits = outputs.logits
    predicted_class = torch.argmax(logits, dim=-1).item()  #obtain best score
    # intention
    predicted_intent = id2label.get(predicted_class, "Unknown Intent")

    if predicted_intent == 'confirm':    #use intention inside
        recommend_ticket_purchase()
    elif predicted_intent == 'deny':
        print("Bot: Okay, have a great day!")
    else:
        print("Bot: I didn't understand your intent")

def classify_intent(user_input):
    inputs = tokenizer(user_input, return_tensors="pt", truncation=True, padding=True)
    outputs = model(**inputs)
    logits = outputs.logits
    intent = logits.argmax().item()    #for taking intention
    return id2label[intent]

#help list
def show_help():
    print("Query movie details (overview, poster, release date) and recommend movies based on preferences.\nGet suggestions for similar movies and receive streaming or cinema ticket info.\nManage your movie "
          "list with add, delete, modify, and query options, and set viewing plans.\nEngage in casual chats or real-time information queries.")

user_name=None
# user_name modify
def change_user_name():
    global user_name
    print(f"Bot: Your current username is '{user_name}'. What would you like to change it to?")
    new_name = input(f"{user_name}: ").strip()
    if new_name:
        user_name = new_name
        print(f"Bot: Got it! I'll call you {user_name} from now on.")
    else:
        print("Bot: You didn't provide a new name, so your username remains unchanged.")

#cleaning text
def clean_text(text):
    text = text.lower()
    text = re.sub(r'[^\w\s]', '', text)
    tokens = word_tokenize(text)
    filtered_tokens = [word for word in tokens if word not in stopwords.words('english')]
    return ' '.join(filtered_tokens)

def handle_daily_conversation(user_input):
    cleaned_user_input = clean_text(user_input)
    conversation_texts = conversation_df['Text'].tolist()
    conversation_texts_cleaned = [clean_text(text) for text in conversation_texts]
    all_texts = conversation_texts_cleaned + [cleaned_user_input]
    tfidf_matrix = vectorizer.fit_transform(all_texts)
    cosine_similarities = cosine_similarity(tfidf_matrix[-1], tfidf_matrix[:-1])
    best_match_idx = cosine_similarities.argmax()
    best_match_text = conversation_df.iloc[best_match_idx]['Text']
    matching_answers = conversation_df[conversation_df['Text'] == best_match_text]['Answer'].tolist()
    response = random.choice(matching_answers) if matching_answers else "Sorry, I couldn't find an answer."
    return response

#Start
print("Bot:Hello, I am a Chatbot for movie recommendations and daily chats.")
time.sleep(2)
print("Bot: Do you mind telling me your name?")
user_response = input("").strip()
intent = classify_intent(user_response)

if intent == 'deny':
    user_name = "Guest"
    print("Bot: Alright, I'll then call you Guest.")
else:
    if user_response:
        user_name = user_response
        print(f"Bot: Nice to meet you, {user_name}!")
    else:
        user_name = "Guest"
        print("Bot: No problem!I'll call you Guest.")

print("Here are some things you can do:")
time.sleep(1)
print("- Type 'change_name' to change your username.")
time.sleep(1)
print("- Type 'help' to view the list of available functions.")
time.sleep(1)
print("- Type 'exit' to leave the chatbot.\n")

while True:
    user_input = input(f"{user_name}:").strip()
    if not user_input:
        print("Bot: Could you please say something?")
        continue

    if user_input.lower() == "change_name":
        change_user_name()
        continue

    if user_input.lower() == "exit":
        print(f"Bot: Goodbye, {user_name}! Have a great day!")
        break

    if user_input.lower() == "help" or "what can you do" in user_input.lower() or "what can you do for me" in user_input.lower():
        show_help()
        continue

    # intention
    inputs = tokenizer(user_input, return_tensors="pt", truncation=True, padding=True)
    outputs = model(**inputs)
    logits = outputs.logits
    probabilities = torch.softmax(logits, dim=1)[0]

    intent_threshold = 0.2   #test better
    detected_intents = [id2label[i] for i, score in enumerate(probabilities) if
                        score > intent_threshold and i in id2label]


    if 'create_favorite_movie_list' in detected_intents:
        create_favorite_movie_list()
        continue

    if 'add_movie_to_list' in detected_intents:
        print("Bot:Please wait a while i'm checking my dataset")
        add_movie_to_list(user_input)
        continue

    if 'query_movie_list' in detected_intents:
        query_movie_list()
        continue

    if 'recommend_similar_movies' in detected_intents:
        recommend_similar_movies(user_input)
        continue

    if 'single_movie_recommendation' in detected_intents:
        filtered_df = filter_movies(user_input)
        recommendation=recommend_single_movie(filtered_df)
        print(recommendation)
        continue

    if 'multiple_movie_recommendations' in detected_intents:
        filtered_df = filter_movies(user_input)
        recommendation2=recommend_multiple_movies(filtered_df, num_recommendations=3)
        print(recommendation2)
        continue

    if 'daily_conversation2' in detected_intents:
        print("Bot: This is a query that requires online information. Please wait while I search.")
        search_results = search_bing_with_snippets(user_input)
        print(f"Bot: {search_results}")
        continue

    if 'recommend_streaming_sites' in detected_intents:
        print("Bot: This is a query that requires online information. Please wait while I search.")
        search_results = search_bing_with_snippets(user_input)
        print(f"Bot: {search_results}")
        continue

    if 'modify_movie_list' in detected_intents:
        response = modify_movie_list()
        print(f"Bot: {response}")
        continue

    if 'recommend_ticket_purchase' in detected_intents:
        response =recommend_ticket_purchase()
        print(f"Bot:{response}")
        continue

    if 'remove_movie_from_list' in detected_intents:
        response = delete_movie_from_list(user_input)
        print(f"Bot: {response}")
        continue


    if 'daily_conversation1' in detected_intents:
        response = handle_daily_conversation(user_input)
        print(f"Bot: {response}")
        continue

    doc = nlp(user_input)
    movie_name = None
    for ent in doc.ents:
        if ent.label_ == 'WORK_OF_ART':
            movie_name = ent.text
            break

    if not movie_name:
        movie_name_match = re.search(r"\b([A-Za-z0-9]+(?:[\s-][A-Za-z0-9]+)*)\b", user_input)
        if movie_name_match:
            movie_name = movie_name_match.group(1)

    if not movie_name:
        print("Bot: Sorry, I couldn't detect a movie title in your message. Can you provide more details?")
        continue

    cleaned_user_input = clean_text(movie_name)

    movie_titles_cleaned = [clean_text(title) for title in movie_titles]
    all_titles = movie_titles_cleaned + [cleaned_user_input]
    tfidf_matrix = vectorizer.fit_transform(all_titles)
    cosine_similarities = cosine_similarity(tfidf_matrix[-1], tfidf_matrix[:-1])
    best_match_idx = cosine_similarities.argmax()
    best_match = movie_titles[best_match_idx]

    if cosine_similarities[0][best_match_idx] < 0.2:
        print("Bot: Sorry, I don't understand what you mean.")
        print("Bot:Could you ask in other ways?")
        continue

    if best_match and detected_intents:
        matched_movie = movie_df[movie_df['Title'] == best_match].iloc[0]
        responses = []
        for intent in detected_intents:
            if intent == 'movie_release_date':
                print("Bot:Please wait a while i'm still checking...")
                responses.append(random.choice([
                    f"The movie '{best_match}' was released on {matched_movie['Release_Date']}.",
                    f"'{best_match}' came out on {matched_movie['Release_Date']}.",
                    f"The release date for '{best_match}' is {matched_movie['Release_Date']}."
                ]))
            elif intent == 'movie_overview':
                print("Bot:Please wait a while i'm still checking...")
                responses.append(random.choice([
                    f"Here's an overview of '{best_match}': {matched_movie['Overview']}.",
                    f"The story of '{best_match}' is as follows: {matched_movie['Overview']}.",
                    f"Summary of '{best_match}': {matched_movie['Overview']}."
                ]))
            elif intent == 'movie_poster_url':
                print("Bot:Please wait a while i'm still checking...")
                url = matched_movie['Poster_Url']
                responses.append(f"I've opened the poster for '{best_match}'.")
                webbrowser.open(url)
            elif intent == 'movie_original_language':
                print("Bot:Please wait a while i'm still checking...")
                responses.append(random.choice([
                    f"The original language of '{best_match}' is {matched_movie['Original_Language']}.",
                    f"'{best_match}' was originally made in {matched_movie['Original_Language']}."
                ]))
                # movie_popularity
            elif intent == 'movie_popularity':
                    print("Bot:Please wait a while i'm still checking...")
                    responses.append(random.choice([
                        f"The movie '{best_match}' has a popularity score of {matched_movie['Popularity']}.",
                        f"The current popularity of '{best_match}' is {matched_movie['Popularity']}.",
                        f"'{best_match}' has a popularity score of {matched_movie['Popularity']}, which indicates how popular it is."
                    ]))

                # movie_vote_average
            elif intent == 'movie_vote_average':
                    print("Bot:Please wait a while i'm still checking...")
                    responses.append(random.choice([
                        f"The average vote for '{best_match}' is {matched_movie['Vote_Average']} out of 10.",
                        f"'{best_match}' has an average rating of {matched_movie['Vote_Average']} from viewers.",
                        f"The movie '{best_match}' holds an average score of {matched_movie['Vote_Average']} based on user ratings."
                    ]))

                # movie_genre
            elif intent == 'movie_genre':
                    print("Bot:Please wait a while i'm still checking...")
                    responses.append(random.choice([
                        f"The genre of '{best_match}' is {matched_movie['Genre']}.",
                        f"'{best_match}' belongs to the following genres: {matched_movie['Genre']}.",
                        f"Genres for '{best_match}' include {matched_movie['Genre']}, which gives you an idea of the movie's style."
                    ]))
        response = " ".join(responses)
    else:
        response = "Sorry, I couldn't detect what you're asking for. Can you clarify?"

    print(f"Bot: {response}")
